angular.module('app.services', [])

.service('ProductApi', ['$http', function($http) {
   
   function getAll() {
        return [
            {
                'sku': '4003341',
                'name': 'Elite Hog Sprinter, M-Pellet 1kg',
                'weight': 1
            }
        ];
   }
   
   function getTopProducts() {
       return [
            {
                'sku': '4003341',
                'name': 'Elite Hog Sprinter, M-Pellet 1kg',
                'weight': 1
            }
        ];
   }
   
   return {
       getAll: getAll,
       getTopProducts: getTopProducts
   };
    
}])

.service('OrderApi', ['$http', function($http) {
    
    function getAll() {
        return [
            {
                'id': '0011',
                'group': 'PFC FEEDS SALES- CENTRAL/EASTERN VISAYAS',
                'party_name': 'Star',
                'product': 'Civic Hog Growex, Pellet 50kg',
                'quantity': 20,
                'ordered_at': '09/15/18',
                'promised_at': '10/10/18',
                'fulfilled': false
            }
        ];
    }
    
    return {
        getAll: getAll
    };
    
}])

.service('ProductionPlanApi', ['$http', function($http) {
    
    function getAll() {
        return [
            {
                'id': 1,
                'production_date': 'June 01, 2018',
                'steps': [
                    {
                        'rank': 1,
                        'sku': '4003341',
                        'quantity': 20,
                        'duration': 1
                    }
                ]
            },
            {
                'id': 2,
                'production_date': 'June 02, 2018',
                'steps': [
                    {
                        'rank': 1,
                        'sku': '4003341',
                        'quantity': 20,
                        'duration': 1
                    }
                ]
            }
        ]
    }
    
    function getOneById(id) {
        return {
            'id': 1,
            'production_date': 'June 01, 2015',
            'steps': [
                {
                    'rank': 1,
                    'sku': '4003341',
                    'quantity': 20,
                    'duration': 1
                }
            ]
        };
    }
    
    function generatePlan() {
        return {
            'id': 1,
            'production_date': 'June 01, 2015',
            'steps': [
                {
                    'rank': 1,
                    'sku': '4003341',
                    'quantity': 20,
                    'duration': 1
                }
            ]
        };
    }
    
    return {
        getAll: getAll,
        getOneById: getOneById,
        generatePlan: generatePlan
    };
    
}])

.service('PriorityApi', ['$http', function($http) {
    
    function getAll() {
        return [
            {
                'rule': 'Color pink first',
                'score': 50
            },
            {
                'rule': 'Promised date',
                'score': 100
            }
        ];
    }
    
    function save(priority) {
        
    }
    
    return {
        getAll: getAll,
        save: save
    };
    
}]);

// .service('ProductionSequenceService', ['$http', function($http) {
//     var apiUrl = 'FIREBASE_HACKTAHON_URL_HERRREREE';
    
//     function getById(id) {
        
//     }
    
//     return {
//       getById: getById
//     };
// }])

// .service('OrderService', ["$firebaseArray", function($firebaseArray){
//     var ref = firebase.database().ref().child("orders");
//     var orders = $firebaseArray(ref);
//     var ret = {
//         orders: orders.map(function(order) {
//             console.log('pasok!');
//                 return {
//                     number: order.order_no,
//                     sku: order.sku,
//                     volume: order.volume,
//                     quantity: order.qty
//                 }
//             }),
//         create: function(order){
//             orders.$add({
//                 order_no: order.number,
//                 sku: order.sku,
//                 volume: order.volume,
//                 qty: order.quantity
//             })
//         },
//     }
//     return ret;
// }]);


// .service('OrderService', ['$http', function($http) {
//     var apiUrl = 'https://sheetsu.com/apis/v1.0su/51a58af92c33';
    
//     function getAll() {
//         return $http.get(apiUrl).then(function(response){
//             return response.data.map(function(order) {
//                 return {
//                     number: order.order_no,
//                     sku: order.sku,
//                     volume: order.volume,
//                     quantity: order.qty
//                 };
//             });
//          });
//     }
    
//     function create(order) {
//         return $http.post(apiUrl, order).then(function(response){ });
//     }
    
//     return {
//         getAll: getAll,
//         create: create
//     };
// }]);