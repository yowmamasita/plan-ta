angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('newOrder', {
    url: '/orders/new',
    templateUrl: 'templates/newOrder.html',
    controller: 'newOrderCtrl'
  })

  .state('orderList', {
    url: '/orders',
    templateUrl: 'templates/orderList.html',
    controller: 'orderListCtrl'
  })

  .state('dashboard', {
    url: '/production-plans',
    templateUrl: 'templates/dashboard.html',
    controller: 'dashboardCtrl'
  })

  .state('productList', {
    url: '/products',
    templateUrl: 'templates/productList.html',
    controller: 'productListCtrl'
  })

  .state('topProducts', {
    url: '/products/top',
    templateUrl: 'templates/topProducts.html',
    controller: 'topProductsCtrl'
  })

  .state('orderDetail', {
    url: '/order',
	params: {
		id: ""		
},
    templateUrl: 'templates/orderDetail.html',
    controller: 'orderDetailCtrl'
  })

  .state('productionPlan', {
    url: '/production-plan',
	params: {
		id: ""		
},
    templateUrl: 'templates/productionPlan.html',
    controller: 'productionPlanCtrl'
  })

  .state('priorities', {
    url: '/priorities',
    templateUrl: 'templates/priorities.html',
    controller: 'prioritiesCtrl'
  })

$urlRouterProvider.otherwise('/production-plans')


});