angular.module('app.controllers', [])
  
.controller('newOrderCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {
    $scope.order = {
        orderNumber: undefined,
        group: undefined,
        partyName: undefined,
        product: undefined,
        sku: undefined,
        quantity: undefined,
        orderedAt: undefined,
        promisedAt: undefined
    };
    
    $scope.isCreateAnotherChecked = true;

    $scope.onCreateAnotherClick = function() {
        $scope.isCreateAnotherChecked = !$scope.isCreateAnotherChecked;
    };

    $scope.onOrderFormSubmit = function() {
        $state.go('orderList');
    };

}])
   
.controller('orderListCtrl', ['$scope', '$stateParams', '$state', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state) {
    $scope.orders = [];

    loadOrders();
    
    function loadOrders() {
        
    }
    
    $scope.onGenerateSequenceClick = function() {
        $state.go('productionPlan');
    };
    
    $scope.onCreateClick = function() {
        $state.go('newOrder');
    };

}])
   
.controller('dashboardCtrl', ['$scope', '$stateParams', '$state', 'ProductionPlanApi', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, ProductionPlanApi) {
    
    $scope.history = [];
    
    loadHistory();
    
    function loadHistory() {
        $scope.history = ProductionPlanApi.getAll();
    }
    
    $scope.onHistoryClick = function(planId) {
        $state.go('productionPlan', { id: planId });
    }
    
    $scope.onGenerateProductionPlanClick = function() {
        var plan = ProductionPlanApi.generatePlan();
        $state.go('productionPlan', { id: plan.id });
    };
    
}])
   
.controller('productListCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('topProductsCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {


}])
   
.controller('orderDetailCtrl', ['$scope', '$stateParams', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams) {

$scope.details = [];

    loadDetails();
    
    function loadDetails() {
        
    }
}])
   
.controller('productionPlanCtrl', ['$scope', '$stateParams', '$state', 'ProductionPlanApi', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, $state, ProductionPlanApi) {

    $scope.plan = {};

    onStart();

    function onStart() {
        var planId = $stateParams.id;
        
        if (!planId) {
            return;
        }
        
        $scope.plan = ProductionPlanApi.getOneById(planId);
    }
}])
   
.controller('prioritiesCtrl', ['$scope', '$stateParams', 'PriorityApi', // The following is the constructor function for this page's controller. See https://docs.angularjs.org/guide/controller
// You can include any angular dependencies as parameters for this function
// TIP: Access Route Parameters for your page via $stateParams.parameterName
function ($scope, $stateParams, PriorityApi) {

    $scope.priorities = [];
    
    onStart();
    
    function onStart() {
        $scope.priorities = PriorityApi.getAll();
    }
}])
 